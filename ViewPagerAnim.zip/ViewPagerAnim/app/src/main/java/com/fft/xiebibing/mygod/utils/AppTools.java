package com.fft.xiebibing.mygod.utils;

import android.app.Activity;
import android.app.Application;
import android.app.Service;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Vibrator;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AppTools {

	/**
	 * 是否符合用户名规则
	 * 
	 * @param username
	 *            4-40位的字母、数字
	 * @return
	 */
	public static boolean isUsername(String username) {
		Pattern pattern = Pattern.compile("^\\w{4,40}$");
		Matcher matcher = pattern.matcher(username);
		return matcher.matches();
	}

	/**
	 * 支付密码校验，6位数字
	 * 
	 * @param payPwd
	 * @return
	 */
	public static boolean isPayPwd(String payPwd) {
		Pattern pattern = Pattern.compile("^\\d{6}$");
		Matcher matcher = pattern.matcher(payPwd);
		return matcher.matches();
	}

	/**
	 * 银行卡校验
	 * 
	 * @param cardNo
	 * @return
	 */
	public static boolean isBankCard(String cardNo) {
		Pattern pattern = Pattern.compile("^\\d{8,20}$");
		Matcher matcher = pattern.matcher(cardNo);
		return matcher.matches();
	}

	/**
	 * FFT卡号长度校验,18位
	 * 
	 * @param cardNo
	 * @return
	 */
	public static boolean isValidFFTCardLength(String cardNo) {
		if (18 == cardNo.length()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 指定规则校验
	 * 
	 * @param validStr
	 * @return
	 */
	public static boolean isMatchPattern(String validStr, String patternStr) {
		Pattern pattern = Pattern.compile(patternStr.trim());
		Matcher matcher = pattern.matcher(validStr);
		return matcher.matches();
	}

	/**
	 * 转换银行卡卡号
	 * 
	 * @param cardNo
	 * @return
	 */
	public static String convertBankCard(String cardNo) {
		return cardNo.substring(0, 4) + " **** **** "
				+ cardNo.substring(cardNo.length() - 4, cardNo.length());
	}

	/**
	 * 转化卡号为*的字符串，保留最后四位，每4位一个空格
	 * 
	 * @param cardNo
	 * @return
	 */
	public static String convertCreditCard(String cardNo) {
		int lenth = cardNo.length();
		if (lenth <= 4) {
			return cardNo;
		} else {
			StringBuffer sb = new StringBuffer();
			for (int i = 0; i < lenth; i++) {

				if (i < lenth - 4) {
					sb.append('*');
				} else {
					sb.append(cardNo.charAt(i));
				}
				if (i % 4 == 3 && i < lenth - 1) {
					sb.append(' ');
				}
			}
			return sb.toString();
		}
	}

	/**
	 * 是否小于今天
	 * 
	 * @param year
	 * @param month
	 * @return
	 */
	public static boolean isBeforeToday(String year, String month) {
		Calendar calendar = Calendar.getInstance();
		int years = Integer.valueOf(year);
		int months = Integer.valueOf(month);
		if (years < calendar.get(Calendar.YEAR)) {
			return true;
		}
		if (years == calendar.get(Calendar.YEAR)
				&& months < calendar.get(Calendar.MONTH) + 1) {
			return true;
		}
		return false;
	}

	/**
	 * 是否符合密码规则
	 * 
	 * @param password
	 *            8-32位的字母、数字、字符（含@_.）
	 * @return
	 */
	public static boolean isPassword(String password) {
		Pattern pattern = Pattern
				.compile("^(?=.*?[a-zA-Z])(?=.*?[0-9])[a-zA-Z0-9@._]{8,32}$");
		Matcher matcher = pattern.matcher(password);
		return matcher.matches();
	}

	/**
	 * 得到日期时间拼接的字符串
	 * 
	 * @return
	 */
	public static String getDateString() {
		Calendar calendar = Calendar.getInstance();
		StringBuilder timeSB = new StringBuilder();
		timeSB.append(calendar.get(Calendar.YEAR));
		int month = calendar.get(Calendar.MONTH) + 1;
		String monthString = month + "";
		if (month < 10) {
			monthString = "0" + month;
		}
		timeSB.append(monthString);
		int day = calendar.get(Calendar.DAY_OF_MONTH);
		String dayString = day + "";
		if (day < 10) {
			dayString = "0" + dayString;
		}
		timeSB.append(dayString);
		int hour = calendar.get(Calendar.HOUR_OF_DAY);
		String hourString = hour + "";
		if (hour < 10) {
			hourString = "0" + hour;
		}
		timeSB.append(hourString);
		int minute = calendar.get(Calendar.MINUTE);
		String mimuteString = minute + "";
		if (minute < 10) {
			mimuteString = "0" + mimuteString;
		}
		timeSB.append(mimuteString);
		int second = calendar.get(Calendar.SECOND);
		String secondString = second + "";
		if (second < 10) {
			secondString = "0" + secondString;
		}
		timeSB.append(secondString);
		return timeSB.toString();
	}

	/**
	 * 输入流转字符串
	 * 
	 * @param postInputStream
	 * @return
	 */
	public static String inputStreamToString(InputStream postInputStream) {
		StringBuilder sb = new StringBuilder();
		try {
			int bufferLen = 1024;
			byte[] data = new byte[1024];
			int dataLen = -1;
			while ((dataLen = postInputStream.read(data, 0, bufferLen)) > 0) {
				sb.append(new String(data, 0, dataLen, "UTF-8"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (postInputStream != null) {
				try {
					postInputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return sb.toString();
	}

	/**
	 * Object.toString()
	 * 
	 * @param obj
	 * @return
	 */
	public static String objectToString(Object obj) {
		return obj != null ? obj.toString() : "";
	}

	/**
	 * task是否支持线程池
	 * 
	 * @return true的话支持 task.executeOnExecutor方法 false只能用task.execute方法
	 */
	public static boolean isSupportThreadPool() {
		return Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB;
	}

	public static String trimString(String str) {

		return str != null ? str.trim() : "";
	}

	/**
	 * 手机号格式是否正确
	 * 
	 * @param phone
	 * @return
	 */
	public static boolean isPhone(String phone) {
		if (TextUtils.isEmpty(phone)) {
			return false;
		}
		// Pattern pattern = Pattern
		// .compile("^((13[0-9])|(14[5,7])|(15[^4,\\D])|(170)|(18[^4,\\D]))\\d{8}$");
		//
		// Matcher matcher = pattern.matcher(phone);
		// return matcher.matches();
		if (phone.length() == 11) {
			return true;
		}
		return false;
	}

	/**
	 * 身份证号格式验证 待补充
	 * 
	 * @param id
	 * @return
	 */
	public static boolean isIdentity(String id) {
		if (TextUtils.isEmpty(id)) {
			return false;
		}

		// 规则待补充
		if (id.length() == 15 || id.length() == 18) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean isSixBitText(String pwd) {
		return (TextUtils.isEmpty(pwd) || pwd.trim().length() != 6);
	}

	public static boolean isValcode(String valcode) {
		return isSixBitText(valcode);
	}

	/**
	 * 付费宝密码格式验证
	 * 
	 * @param pwd
	 * @return
	 */
	public static boolean isFFBPwd(String pwd) {
		Pattern pattern = Pattern.compile("^\\d{6}$");
		Matcher matcher = pattern.matcher(pwd);
		return matcher.matches();
	}

	/**
	 * 根据手机的分辨率从 dp 的单位 转成为 px(像素)
	 */
	public static int dip2px(Context context, float dpValue) {
		final float scale = context.getResources().getDisplayMetrics().density;
		return (int) (dpValue * scale + 0.5f);
	}

	/**
	 * 根据手机的分辨率从 px(像素) 的单位 转成为 dp
	 */
	public static int px2dip(Context context, float pxValue) {
		final float scale = context.getResources().getDisplayMetrics().density;
		return (int) (pxValue / scale + 0.5f);
	}

	/**
	 * 收起软键盘
	 */
	public static void collapseSoftInputMethod(Activity activity, View editView) {

		if (activity != null) {
			InputMethodManager imm = (InputMethodManager) activity
					.getSystemService(Context.INPUT_METHOD_SERVICE);
			if (imm != null && editView != null) {
				imm.hideSoftInputFromWindow(editView.getWindowToken(),
						InputMethodManager.HIDE_NOT_ALWAYS);
			}
		}

	}

	/**
	 * 收起软键盘
	 */
	public static void collapseSoftInputMethod(Activity activity) {
		activity.getWindow().setSoftInputMode(
				WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
	}

	/**
	 * 收起软键盘
	 */
	public static void upfoldSoftInputMethod(Activity activity, EditText et) {
		InputMethodManager imm = (InputMethodManager) activity
				.getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.showSoftInput(et, InputMethodManager.RESULT_SHOWN);
		imm.toggleSoftInput(InputMethodManager.SHOW_FORCED,
				InputMethodManager.HIDE_IMPLICIT_ONLY);
	}

	/**
	 * 收起软键盘
	 */
	public static void collapseSoftInputMethod2(Activity activity) {
		InputMethodManager inputMethodManager = (InputMethodManager) activity
				.getSystemService(Context.INPUT_METHOD_SERVICE);
		if (activity.getCurrentFocus() != null)
			inputMethodManager.hideSoftInputFromWindow(activity
					.getCurrentFocus().getWindowToken(),
					InputMethodManager.HIDE_NOT_ALWAYS);

	}

	/**
	 * 得到应用的包信息
	 * 
	 * @param application
	 * @return
	 * @throws NameNotFoundException
	 */
	public static PackageInfo getAppPackageInfo(Application application)
			throws NameNotFoundException {
		PackageInfo packageInfo = null;
		packageInfo = application.getPackageManager().getPackageInfo(
				"com.shfft.tenter", 0);
		return packageInfo;
	}

	/**
	 * 生成伪造的id
	 * 
	 * @return
	 */
	public static String generateDummyId() {
		Calendar calendar = Calendar.getInstance();
		StringBuilder timeSB = new StringBuilder();
		timeSB.append(calendar.get(Calendar.MONTH) + 1);
		timeSB.append(calendar.get(Calendar.DAY_OF_MONTH));
		timeSB.append(calendar.get(Calendar.HOUR_OF_DAY));
		timeSB.append(calendar.get(Calendar.MINUTE));
		timeSB.append(calendar.get(Calendar.SECOND));
		return timeSB.toString();
	}

	/**
	 * 手机震动
	 * 
	 * @param context
	 * @param milliseconds
	 */
	public static void vibrate(Context context, long milliseconds) {
		Vibrator vib = (Vibrator) context
				.getSystemService(Service.VIBRATOR_SERVICE);
		vib.vibrate(milliseconds);
	}

	/**
	 * 请求参数排序
	 * 
	 * @param map
	 * @return
	 */
	public static String sortRequestSign(TreeMap<String, String> map) {
		if (map != null) {
			StringBuilder sb = new StringBuilder();
			for (Entry<String, String> entry : map.entrySet()) {
				String value = entry.getValue();
				if (value != null) {
					sb.append("&" + entry.getKey() + "=" + value);
				}
			}
			if (sb.length() > 0) {
				sb.deleteCharAt(0);
			}
			return sb.toString();
		}
		return "";
	}

	/**
	 * 判断金额输入是否正确
	 * 
	 * @param money
	 * @return
	 */
	public static boolean isMoney(String money) {
		Pattern pattern = Pattern
				.compile("^(([1-9]{1}[0-9]*?)|0)(\\.[0-9]{1,2})??$");
		Matcher matcher = pattern.matcher(money);
		return matcher.matches();
	}

	public static int getWidthFromView(View v) {
		int w = View.MeasureSpec.makeMeasureSpec(0,
				View.MeasureSpec.UNSPECIFIED);
		int h = View.MeasureSpec.makeMeasureSpec(0,
				View.MeasureSpec.UNSPECIFIED);
		v.measure(w, h);
		int width = v.getMeasuredWidth();
		// int height =v.getMeasuredHeight();
		return width;
	}

	public static int[] getMesureFromView(View v) {
		int w = View.MeasureSpec.makeMeasureSpec(0,
				View.MeasureSpec.UNSPECIFIED);
		int h = View.MeasureSpec.makeMeasureSpec(0,
				View.MeasureSpec.UNSPECIFIED);
		v.measure(w, h);
		int width = v.getMeasuredWidth();
		int height = v.getMeasuredHeight();
		return new int[] { width, height };
	}

	/**
	 * 获取半年前月份
	 * 
	 * @return
	 */
	public static String getHistoryMonth() {
		Calendar calendar = Calendar.getInstance();
		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH) + 1;
		if (month < 7) {
			year--;
			month = month + 6;
		} else {
			month = month - 6;
		}
		String monthString = month + "";
		if (month < 10) {
			monthString = "0" + month;
		}
		return year + monthString;
	}

	/**
	 * 将100分转成1.00元
	 * 
	 * @param money
	 * @return
	 */
	public static String convertMoney(String money) {
		if (!TextUtils.isEmpty(money)) {
			if (money.length() > 2) {
				return money.substring(0, money.length() - 2) + "."
						+ money.substring(money.length() - 2, money.length());
			} else if (money.length() == 2) {
				return "0." + money;
			} else if (money.length() == 1) {
				return "0.0" + money;
			} else {
				return "0.00";
			}
		}
		return "";
	}

	/**
	 * 弹出提示框
	 * 
	 * @param context
	 * @param resId
	 */
	public static void showToast(Context context, int resId) {
		Toast.makeText(context, context.getString(resId), Toast.LENGTH_LONG)
				.show();
	}

	/**
	 * 弹出提示框
	 * 
	 * @param context
	 * @param
	 */
	public static void showToast(Context context, String text) {
		Toast.makeText(context, text, Toast.LENGTH_LONG).show();
	}

	/**
	 * 获取app版本(内部)
	 * 
	 * @param context
	 * @return
	 */
	public static String getAppVersionCode(Context context) {
		String version = "";
		try {
			version = context.getPackageManager().getPackageInfo(
					context.getPackageName(), 0).versionCode
					+ "";
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}
		return version;
	}

	/**
	 * 获取app版本(外部，显示在检查版本旁边)
	 * 
	 * @param context
	 * @return
	 */
	public static String getAppVersionName(Context context) {
		String version = "";
		try {
			version = context.getPackageManager().getPackageInfo(
					context.getPackageName(), 0).versionName
					+ "";
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}
		return version;
	}

	/**
	 * 日期转化成时间戳
	 */
	public static long strFormatCovertData(String date) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date d = null;
		try {
			d = format.parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		if (d == null) {
			return -1;
		} else {
			return d.getTime();
		}
	}

	/**
	 * 编辑控件取空格
	 * 
	 * @param et
	 */
	public static void trimSpace(EditText et) {
		et.setFilters(new InputFilter[] { new InputFilter() {

			@Override
			public CharSequence filter(CharSequence source, int start, int end,
									   Spanned dest, int dstart, int dend) {

				if (source instanceof Spanned) {
					return null;
				} else {
					return source.toString().replace(" ", "");
				}
			}
		} });
	}

	/**
	 * 编辑控件取空格不允许中文
	 * 
	 * @param et
	 */
	public static void trimSpaceNotAllowChinese(EditText et) {
		et.setFilters(new InputFilter[] { new InputFilter() {

			@Override
			public CharSequence filter(CharSequence source, int start, int end,
									   Spanned dest, int dstart, int dend) {
				StringBuffer sb = new StringBuffer();
				for (int i = 0; i < source.length(); i++) {
					if (' ' == source.charAt(i)) {
						// 除去空格
						continue;
					}

					if ((source.charAt(i) >= 0x4e00)
							&& (source.charAt(i) <= 0x9fbb)) {
						// 不支持中文，并且检测到是中文
						continue;
					} else {
						// 不支持中文，不做限制
						sb.append(source.charAt(i));
					}

				}
				return sb.toString().replace(" ", "");
			}
		} });
	}

	/**
	 * 编辑控件取空格
	 * 
	 * @param et
	 */
	public static void trimSpaceAndLength(EditText et, int length) {
		et.setFilters(new InputFilter[] { new InputFilter() {

			@Override
			public CharSequence filter(CharSequence source, int start, int end,
									   Spanned dest, int dstart, int dend) {
				return source.toString().replace(" ", "");
			}
		}, new InputFilter.LengthFilter(length) });
	}

	/**
	 * 格式化日期（yyyy年MM月）
	 * 
	 * @param date
	 * @return
	 */
	public static String convertDateStr(String date) {
		DateFormat format = new SimpleDateFormat("yyyyMM");
		Date dDate = null;
		try {
			dDate = format.parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		DateFormat format2 = new SimpleDateFormat("yyyy年MM月");
		String reTime = format2.format(dDate);
		return reTime;
	}

	public static String convertDateStrYMD(String date) {
		if (date == null) {
			return null;
		}
		DateFormat format = new SimpleDateFormat("yyyyMMdd");
		Date dDate = null;
		try {
			dDate = format.parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
		DateFormat format2 = new SimpleDateFormat("yyyy年MM月dd日");
		String reTime = format2.format(dDate);
		return reTime;
	}

	/**
	 * 获取屏幕宽高
	 * 
	 * @param context
	 * @return
	 */
	public static int[] getScreenHW(Context context) {
		WindowManager manager = (WindowManager) context
				.getSystemService(Context.WINDOW_SERVICE);
		DisplayMetrics dm = new DisplayMetrics();
		manager.getDefaultDisplay().getMetrics(dm);
		int width = dm.widthPixels;
		int height = dm.heightPixels;
		return new int[] { width, height };
	}

	/**
	 * 格式化日期（yyyy/MM）
	 * 
	 * @param date
	 * @return
	 */
	public static String convertDateStr1(String date) {
		DateFormat format = new SimpleDateFormat("yyyyMM");
		Date dDate = null;
		try {
			dDate = format.parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		DateFormat format2 = new SimpleDateFormat("yyyy/MM");
		String reTime = format2.format(dDate);
		return reTime;
	}

	public static void closeDialog(DialogInterface dialog, boolean close) {
		Field field;
		try {
			field = dialog.getClass().getSuperclass()
					.getDeclaredField("mShowing");
			field.setAccessible(true);
			// 设置mShowing值，欺骗android系统
			field.set(dialog, close);// 如果为true则会推出
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 判定输入汉字
	 * 
	 * @param c
	 * @return
	 */
	private static boolean isChinese(char c) {
		Character.UnicodeBlock ub = Character.UnicodeBlock.of(c);
		if (ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS
				|| ub == Character.UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS
				|| ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A
				|| ub == Character.UnicodeBlock.GENERAL_PUNCTUATION
				|| ub == Character.UnicodeBlock.CJK_SYMBOLS_AND_PUNCTUATION
				|| ub == Character.UnicodeBlock.HALFWIDTH_AND_FULLWIDTH_FORMS) {
			return true;
		}
		return false;
	}

	/**
	 * 检测String是否全是中文
	 * 
	 * @param name
	 * @return
	 */
	public static boolean checkNameChese(String name) {
		boolean res = true;
		char[] cTemp = name.toCharArray();
		for (int i = 0; i < name.length(); i++) {
			if (!isChinese(cTemp[i])) {
				res = false;
				break;
			}
		}
		return res;
	}

	/*
	 * 拨打电话模块
	 */
	public static void phoneCall(Context context, String phoneNumber) {
		Intent phoneIntent = new Intent("android.intent.action.CALL",
				Uri.parse("tel:" + phoneNumber));
		context.startActivity(phoneIntent);
	}

	/*
	 * 获取manifest中Application级别的meta信息
	 */
	public static String getApplicationMetaInfo(Context context, String name) {
		ApplicationInfo appInfo;
		String msg = null;
		try {
			appInfo = context.getPackageManager().getApplicationInfo(
					context.getPackageName(), PackageManager.GET_META_DATA);
			msg = appInfo.metaData.getString(name);
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}

		return msg;
	}

	/**
	 * 延迟显示输入键盘
	 */
	public static void showSoftKeywordDelay(final EditText editText,
			long delayTimes) {
		if (editText != null) {
			Handler handler = new Handler();
			handler.postDelayed(new Runnable() {

				@Override
				public void run() {
					editText.requestFocus();
					InputMethodManager inputManager = (InputMethodManager) editText
							.getContext().getSystemService(
									Context.INPUT_METHOD_SERVICE);
					inputManager.showSoftInput(editText, 0);
				}
			}, delayTimes);
		}
	}

	public static boolean isEmpty(String str) {
		if (TextUtils.isEmpty(str) || "null".equals(str)) {
			return true;
		} else {
			return false;
		}
	}


	/**
	 * 格式化付费通卡 962233 1234 1234 1234
	 * 
	 * @param cardNo
	 * @return
	 */
	public static String converFFTCard(String cardNo) {
		String result = cardNo;
		if (!TextUtils.isEmpty(result)) {
			StringBuffer sb = new StringBuffer(result);
			if (sb.length() > 6) {
				sb.insert(6, " ");
			}
			if (sb.length() > 11) {
				sb.insert(11, " ");
			}
			if (sb.length() > 16) {
				sb.insert(16, " ");
			}
			result = sb.toString();
		}
		return result;
	}


	public static String getCardNoEndWithoutHint(String cardNo) {
		String tail = null;
		if (cardNo.length() >= 4) {
			tail = cardNo.substring(cardNo.length() - 4, cardNo.length());
		} else if (cardNo.length() == 0 || TextUtils.isEmpty(cardNo)) {
			return "";
		} else {
			tail = cardNo;
		}
		return String.format("(%s)", tail);
	}

	public static String getApplicationMetaData(Activity act, String name) {
		ApplicationInfo appInfo;
		String msg = null;
		try {
			appInfo = act.getPackageManager().getApplicationInfo(
					act.getPackageName(), PackageManager.GET_META_DATA);

			msg = appInfo.metaData.getString("UMENG_CHANNEL");
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}

		return msg;
	}

	public static boolean isEmptyList(List list) {
		if (null != list && 0 != list.size()) {
			return false;
		} else {
			return true;
		}
	}

	public static boolean isValidTransCardNumber(String cardno) {
		if (TextUtils.isEmpty(cardno)) {
			return false;
		}

		if (cardno.length() < 10 || cardno.length() > 15) {
			return false;
		}

		return true;
	}

	public static String getOccupiedString(Context context, int res,
										   String value) {
		String data = context.getString(res);
		data = String.format(data, value);
		return data;
	}


	/**
	 * 校验邮箱
	 */
	public static boolean isEmail(String email) {
		String str = "^([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$";
		Pattern p = Pattern.compile(str);
		Matcher m = p.matcher(email);

		return m.matches();
	}

	/**
	 * 校验手机号
	 */

//	public static boolean isPhone(String phoneNumber) {
//		String str = "^[1][358][0-9]{9}$";
//		Pattern p = Pattern.compile(str);
//		Matcher m = p.matcher(phoneNumber);
//
//		return m.matches();
//	}


}
