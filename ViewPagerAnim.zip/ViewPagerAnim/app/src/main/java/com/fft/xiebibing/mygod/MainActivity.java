package com.fft.xiebibing.mygod;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

import com.fft.xiebibing.mygod.customize.ZoomOutSlideTransformer;
import com.fft.xiebibing.mygod.fragment.BlankFragment;
import com.fft.xiebibing.mygod.fragment.ItemFragment;
import com.fft.xiebibing.mygod.fragment.PlusOneFragment;
import com.fft.xiebibing.mygod.fragment.dummy.DummyContent;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements
        ItemFragment.OnListFragmentInteractionListener,
        PlusOneFragment.OnFragmentInteractionListener,
        BlankFragment.OnFragmentInteractionListener{

    List<Fragment> fragments = null;
    private PageAdapter mAdapter;
    ViewPager mPager = null;
    boolean isLogin = false;
    public static final int[] COLORS = new int[] { 0xFF33B5E5, 0xFFAA66CC, 0xFF99CC00, 0xFFFFBB33, 0xFFFF4444 };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        initFloatActionButton();
        initFragment();
    }

    private void initFragment() {
        if (fragments == null){
            fragments = new ArrayList<>();
        }
        if (fragments.size()>=3){
            //do nothing
        }else {
            fragments.add(new BlankFragment());
            fragments.add(new ItemFragment());
            fragments.add(new PlusOneFragment());
        }

        mAdapter = new PageAdapter(getSupportFragmentManager());

        mPager = (ViewPager) findViewById(R.id.container);
        mPager.setAdapter(mAdapter);
        mPager.setPageTransformer(true,new ZoomOutSlideTransformer());
    }

    private void initFloatActionButton() {
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                isLogin = !isLogin;
                if (isLogin){
                    Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                }else {
                    startActivity(new Intent(MainActivity.this,LoginActivity.class));
                }

            }
        });
    }

    @Override
    public void onListFragmentInteraction(DummyContent.DummyItem item) {

    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }


    private class PageAdapter extends FragmentStatePagerAdapter {
        public PageAdapter(FragmentManager fragmentManager){
            super(fragmentManager);
        }
        @Override
        public Fragment getItem(int position) {
            return fragments.get(position);
        }

        @Override
        public int getCount() {
            return fragments.size();
        }

    }


}
