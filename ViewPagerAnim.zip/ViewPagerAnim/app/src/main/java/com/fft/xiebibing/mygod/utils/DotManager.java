package com.fft.xiebibing.mygod.utils;

import android.text.TextUtils;

import java.util.HashMap;
import java.util.Map;

public class DotManager {

    private static DotManager self;
    private static Map<String, Object> map = null;

    public static final String TAB1 = "TAB1";
    public static final String TAB2 = "TAB2";
    public static final String TAB3 = "TAB3";
    public static final String TAB4 = "TAB4";

    public static DotManager getInstance() {
        if (null == self) {
            self = new DotManager();
            map = new HashMap<String, Object>();
        }

        return self;
    }

    public DotManager put(String key, Object value) {
        if (null == map || TextUtils.isEmpty(key)) {
            return null;
        }
        map.put(key, value);
        return self;
    }

    public IDot get(String key) {
        if (null == map || TextUtils.isEmpty(key)) {
            return null;
        }
        return (IDot) map.get(key);
    }

    public void clear() {
        map.clear();
    }

    public void showDot(String key) {
        get(key).show();
    }

    public void hideDot(String key) {
        get(key).hide();
    }

    public interface IDot {

        void show();

        void hide();
    }
}
