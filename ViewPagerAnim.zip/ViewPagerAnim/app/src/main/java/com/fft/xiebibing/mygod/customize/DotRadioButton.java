package com.fft.xiebibing.mygod.customize;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.RadioButton;

import com.fft.xiebibing.mygod.utils.AppTools;
import com.fft.xiebibing.mygod.utils.DotManager;


public class DotRadioButton extends RadioButton implements DotManager.IDot {

	private boolean needdot = false;
	private int dotColor = Color.RED;
	private int offsetHorizontal = 10;
	private int offsetVertical = 10;
	private int dotRadius = 5;
	private final static int DEFAULT_DOT_SIZE = 4;
	public DotRadioButton(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
		super(context, attrs, defStyleAttr);

	}

	public DotRadioButton(Context context, AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);

	}

	public DotRadioButton(Context context, AttributeSet attrs) {
		super(context, attrs);

	}

	public DotRadioButton(Context context) {
		super(context);

	}

	@Override
	protected void onFinishInflate() {
		super.onFinishInflate();
		dotRadius = AppTools.dip2px(getContext(),DEFAULT_DOT_SIZE);
	}

	public void showDot() {
		needdot = true;
		invalidate();
	}

	public void hideDot() {
		needdot = false;
		invalidate();
	}

	public void setOffsetHorizontal(int offset) {
		this.offsetHorizontal = offset;
	}

	public void setOffsetVertical(int offset) {
		this.offsetVertical = offset;
	}

	public void setDotColor(int dotColor) {
		this.dotColor = dotColor;
	}

	public void setDotRadius(int dotRadius) {
		this.dotRadius = dotRadius;
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);

		if (needdot) {
			canvas.save();
			int width = getMeasuredWidth();
			int hight = getMeasuredHeight();
			Paint paint = getPaint();
			paint.setStrokeWidth(5f);
			paint.setAntiAlias(true);
			paint.setColor(dotColor);
			paint.setStyle(Paint.Style.FILL);
			//横向中心向两边偏移
//			canvas.drawCircle(width/2 + offsetHorizontal, offsetVertical, dotRadius, paint);
			getDotPoint(point);
			canvas.drawCircle(point.x,point.y, dotRadius, paint);
			canvas.restore();
		}

	}
	private Point point = new Point();
	private void getDotPoint(Point point){
		Drawable[] ds = getCompoundDrawables();
		if(ds.length > 2 && ds[1] != null){
			final Drawable top = ds[1];
			int w = top.getIntrinsicWidth();
			point.x = (getMeasuredWidth() + w) / 2 - dotRadius;
			point.y = dotRadius;
		}else{
			point.x = getMeasuredWidth() - dotRadius;
			point.y = dotRadius;
		}
	}

	@Override
	public void show() {
		showDot();
	}

	@Override
	public void hide() {
		hideDot();
	}

}
